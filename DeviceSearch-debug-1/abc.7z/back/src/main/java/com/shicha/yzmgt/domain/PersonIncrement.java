package com.shicha.yzmgt.domain;

public class PersonIncrement {

	String deviceNo;
	String updateDateStart;
	String updateDateEnd;
	public String getDeviceNo() {
		return deviceNo;
	}
	public void setDeviceNo(String deviceNo) {
		this.deviceNo = deviceNo;
	}
	public String getUpdateDateStart() {
		return updateDateStart;
	}
	public void setUpdateDateStart(String updateDateStart) {
		this.updateDateStart = updateDateStart;
	}
	public String getUpdateDateEnd() {
		return updateDateEnd;
	}
	public void setUpdateDateEnd(String updateDateEnd) {
		this.updateDateEnd = updateDateEnd;
	}
}
