export const TOGGLE_DEVICE = 'TOGGLE_DEVICE';

export const TOGGLE_SIDEBAR = 'TOGGLE_SIDEBAR';

export const EXPAND_MENU = 'EXPAND_MENU';

export const SWITCH_EFFECT = 'SWITCH_EFFECT';

// login user info
export const LOGIN_UPDARE = 'LOGIN_UPDARE';
export const LOGIN_RESET = 'LOGIN_COMMIT';


