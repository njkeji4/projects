package com.shicha.dianbiao.demon.domain;

public class RawCmd {

	String addr;
	byte[] buff;
	
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public byte[] getBuff() {
		return buff;
	}
	public void setBuff(byte[] buff) {
		this.buff = buff;
	}
	
	
}
