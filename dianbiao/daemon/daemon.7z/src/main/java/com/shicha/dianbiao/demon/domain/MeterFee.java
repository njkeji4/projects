package com.shicha.dianbiao.demon.domain;

public class MeterFee extends Meter{

}
