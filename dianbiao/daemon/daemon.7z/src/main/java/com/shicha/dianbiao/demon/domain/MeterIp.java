package com.shicha.dianbiao.demon.domain;

public class MeterIp extends Meter{

}
