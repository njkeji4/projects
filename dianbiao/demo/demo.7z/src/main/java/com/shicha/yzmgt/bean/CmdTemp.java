package com.shicha.yzmgt.bean;

public class CmdTemp {

	String name;
	String content;
}
