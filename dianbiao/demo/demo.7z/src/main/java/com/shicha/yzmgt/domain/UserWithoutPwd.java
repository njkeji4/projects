package com.shicha.yzmgt.domain;

public interface UserWithoutPwd {

	
	public String getId();
	
	public String getName(); 
	
	public String getRole();
	
}
